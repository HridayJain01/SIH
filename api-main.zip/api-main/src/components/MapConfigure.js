const GOOGLE_MAPS_API_KEY = 'AIzaSyBOYnR592HFsg67oCuu2_XlI9vviDYyf_o' ;
export const mapoptions = {
googleMapApiKey: GOOGLE_MAPS_API_KEY,
}